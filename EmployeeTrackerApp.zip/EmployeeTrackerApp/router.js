﻿//'use strict';
//app.config(function ($routeProvider,  $locationProvider) {
//    $routeProvider
//        .when("/", {
//            templateUrl: "/src/views/empList.html",
//            controller: "EmpController"
//        })
//        .when("/CreateEmp", {
//            templateUrl: "/EmployeeTracker/Details",
//            controller: "EmpController"
//        })
//        .when("/UpdateEmp", {
//            templateUrl: "/src/views/empEdit.html",
//            controller: "EmpController"
//        })

//    // use the HTML5 History API
//    $locationProvider.html5Mode({ enabled: true, requireBase: false });
//}); 