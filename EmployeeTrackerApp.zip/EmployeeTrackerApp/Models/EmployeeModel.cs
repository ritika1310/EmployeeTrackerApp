﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EmployeeTrackerApp.Models
{
    public class EmployeeModel
    {

        public int ID { get; set; }
        [Required]
        [StringLength(5, MinimumLength = 3)]
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public string Department { get; set; }

    }
}