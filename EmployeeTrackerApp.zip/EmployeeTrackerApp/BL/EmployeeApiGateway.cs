﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeTrackerApp.BL
{
    public class EmployeeApiGateway
    {
    //    System.Net.Http.HttpClient clientr = new System.Net.Http.HttpClient();
    //    clientr.BaseAddress = new Uri("http://localhost:56129/");
    //    //client.DefaultRequestHeaders.Add("",)  

    //    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    //    // HttpResponseMessage response = client.PostAsJsonAsync("api/Employe/InsertEmploye",e1).Result;  
    //    HttpResponseMessage response = client.PostAsJsonAsync("api/Employe/InsertEmploye", e1).Result;
    //}
}