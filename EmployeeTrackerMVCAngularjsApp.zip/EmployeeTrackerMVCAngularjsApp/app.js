﻿'use strict';

// Creating angular app named EMPModule
var app = angular.module("EMP_MODULE", ["ngRoute", 'ui.bootstrap']);